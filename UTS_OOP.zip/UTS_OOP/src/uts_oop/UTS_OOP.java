
package uts_oop;

import java.util.Scanner;

class KonversiUang {
    double nilaiRupiah;
    double hasilKonversi;
    String mataUangTujuan;

    // Method untuk menentukan nilai tukar
    double getKurs(String mataUang) {
        switch (mataUang.toLowerCase()) {
            case "usd":  // Dollar Amerika
                return 0.000065; // 1 Rupiah = 0.000065 USD
            case "eur":  // Euro
                return 0.000052; 
            case "jpy":  // Yen Jepang
                return 0.0092; 
            case "sgd":  // Dollar Singapura
                return 0.000078;
            case "myr":  // Ringgit Malaysia
                return 0.00025;
            default:
                return 0; // Jika tidak valid
        }
    }

    // Method untuk melakukan konversi
    void konversi() {
        double kurs = getKurs(mataUangTujuan);
        hasilKonversi = nilaiRupiah * kurs;
    }

    // Method untuk menampilkan hasil konversi seperti struk
    void tampilkanHasil() {
        System.out.println("\n==============================");
        System.out.println("   PROGRAM KONVERSI MATA UANG ");
        System.out.println("==============================");
        System.out.println("Nilai Rupiah    : Rp " + nilaiRupiah);
        System.out.println("Mata Uang Tujuan: " + mataUangTujuan.toUpperCase());

        if (getKurs(mataUangTujuan) == 0) {
            System.out.println("⚠️ Mata uang tidak valid! (Gunakan: USD, EUR, JPY, SGD, MYR)");
        } else {
            System.out.printf("Hasil Konversi  : %.4f %s\n", hasilKonversi, mataUangTujuan.toUpperCase());
        }
        
        System.out.println("==============================");
        System.out.println("Terima kasih telah menggunakan layanan konversi!");
        System.out.println("==============================");
    }
}

public class UTS_OOP {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        KonversiUang konversi = new KonversiUang();

        System.out.println("=== PROGRAM KONVERSI MATA UANG ===");
        System.out.print("Masukkan jumlah uang (Rupiah): Rp. ");
        konversi.nilaiRupiah = input.nextDouble();

        System.out.print("Masukkan mata uang tujuan (USD / EUR / JPY / SGD / MYR): ");
        konversi.mataUangTujuan = input.next();

        konversi.konversi();
        konversi.tampilkanHasil();
    }
}
